import { Game } from './Game.js';

window.addEventListener('load', () => {
    const game = new Game();
    game.start();
});
